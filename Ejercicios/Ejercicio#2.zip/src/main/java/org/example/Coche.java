package org.example;

public class Coche {
    int numeroPuertas = 4;


    public void añadirPuerta(){
        this.numeroPuertas++;
    }
}