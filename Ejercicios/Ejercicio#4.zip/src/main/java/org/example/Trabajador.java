package org.example;

public class Trabajador extends Persona{
    private double salario;
    
    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}
